using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform player;    // Il riferimento al personaggio
    public float smoothSpeed = 0.125f;  // Velocità con cui la telecamera segue
    public Vector3 offset;      // Distanza dalla telecamera al personaggio

    void Start()
    {
        // Imposta un offset iniziale, puoi regolarlo nell'Inspector
        offset = transform.position - player.position;
    }

    void LateUpdate()
    {
        // Calcola la posizione desiderata della telecamera (solo x e y)
        Vector3 desiredPosition = new Vector3(player.position.x, player.position.y, transform.position.z);
        
        // Muove la telecamera con una certa velocità per renderla più fluida
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);
        transform.position = smoothedPosition;
    }
}
